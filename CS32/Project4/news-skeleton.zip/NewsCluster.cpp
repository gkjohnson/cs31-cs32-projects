#include "provided.h"
#include <string>
#include <utility>
using namespace std;

class NewsClusterImpl
{
public:
    NewsClusterImpl();
    bool submitKernelStory(string headline, string url);
    bool submitStory(string headline, string url);
    string getIdentifier() const;
    bool getFirstNewsItem(string& headline, string& url);
    bool getNextNewsItem(string& headline, string& url);
    int size() const;
};

NewsClusterImpl::NewsClusterImpl()
{
}

bool NewsClusterImpl::submitKernelStory(string headline, string url)
{
    return false;
}

bool NewsClusterImpl::submitStory(string headline, string url)
{
    return false;
}

string NewsClusterImpl::getIdentifier() const
{
    return "";
}

bool NewsClusterImpl::getFirstNewsItem(string& headline, string& url)
{
    return false;
}

bool NewsClusterImpl::getNextNewsItem(string& headline, string& url)
{
    return false;
}

int NewsClusterImpl::size() const
{
    return 0;
}

//******************** NewsCluster functions **********************************

// These functions simply delegate to NewsClusterImpl's functions.

NewsCluster::NewsCluster()
{
    m_impl = new NewsClusterImpl();
}

NewsCluster::~NewsCluster()
{
    delete m_impl;
}

NewsCluster::NewsCluster(const NewsCluster& other)
{
    m_impl = new NewsClusterImpl(*other.m_impl);
}

NewsCluster& NewsCluster::operator=(const NewsCluster& rhs)
{
    if (this != &rhs)
    {
        NewsCluster temp(rhs);
        std::swap(m_impl, temp.m_impl);
    }
    return *this;
}

bool NewsCluster::submitKernelStory(string headline, string url)
{
    return m_impl->submitKernelStory(headline, url);
}

bool NewsCluster::submitStory(string headline, string url)
{
    return m_impl->submitStory(headline, url);
}

string NewsCluster::getIdentifier() const
{
    return m_impl->getIdentifier();
}

bool NewsCluster::getFirstNewsItem(string& headline, string& url)
{
    return m_impl->getFirstNewsItem(headline, url);
}

bool NewsCluster::getNextNewsItem(string& headline, string& url)
{
    return m_impl->getNextNewsItem(headline, url);
}

int NewsCluster::size() const
{
    return m_impl->size();
}
