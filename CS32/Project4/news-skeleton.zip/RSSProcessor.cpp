#include "provided.h"
#include <string>
using namespace std;

class RSSProcessorImpl
{
public:
    RSSProcessorImpl(string rssURL);
    bool getData();
    bool getFirstItem(string& link, string& title);
    bool getNextItem(string& link, string& title);
};

RSSProcessorImpl::RSSProcessorImpl(string rssURL)
{
}

bool RSSProcessorImpl::getData()
{
    return false;
}

bool RSSProcessorImpl::getFirstItem(string& link, string& title)
{
    return false;
}

bool RSSProcessorImpl::getNextItem(string& link, string& title)
{
    return false;
}

//******************** RSSProcessor functions **********************************

// These functions simply delegate to RSSProcessorImpl's functions.

RSSProcessor::RSSProcessor(string rssURL)
{
    m_impl = new RSSProcessorImpl(rssURL);
}

RSSProcessor::~RSSProcessor()
{
    delete m_impl;
}

bool RSSProcessor::getData()
{
    return m_impl->getData();
}

bool RSSProcessor::getFirstItem(string& link, string& title)
{
    return m_impl->getFirstItem(link, title);
}

bool RSSProcessor::getNextItem(string& link, string& title)
{
    return m_impl->getNextItem(link, title);
}
