#ifndef _MAPPER_H_
#define _MAPPER_H_

template<typename T>
class StringMapper
{
public:
    StringMapper();
    ~StringMapper();
    void insert(std::string from, const T& to);
    bool find(std::string from, T& to) const;
    bool getFirstPair(std::string& from, T& to);
    bool getNextPair(std::string& from, T& to);
    int size() const;
};

#endif // _MAPPER_H_
