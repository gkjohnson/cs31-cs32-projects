#include "provided.h"
#include <string>
using namespace std;

class NewsAggregatorImpl
{
public:
    NewsAggregatorImpl();
    void addSourceRSSFeed(string feed);
    int getTopStoriesAndKeywords(double thresholdPercentage,
                    vector<Cluster>& topStories, vector<Keyword>& topKeywords);
};

NewsAggregatorImpl::NewsAggregatorImpl()
{
}

void NewsAggregatorImpl::addSourceRSSFeed(string feed)
{
}

int NewsAggregatorImpl::getTopStoriesAndKeywords(double thresholdPercentage,
                    vector<Cluster>& topStories, vector<Keyword>& topKeywords)
{
    return 0;
}

//******************** NewsAggregator functions *******************************

// These functions simply delegate to NewsAggregatorImpl's functions.

NewsAggregator::NewsAggregator()
{
    m_impl = new NewsAggregatorImpl();
}

NewsAggregator::~NewsAggregator()
{
    delete m_impl;
}

void NewsAggregator::addSourceRSSFeed(string feed)
{
    m_impl->addSourceRSSFeed(feed);
}

int NewsAggregator::getTopStoriesAndKeywords(double thresholdPercentage,
                    vector<Cluster>& topStories, vector<Keyword>& topKeywords)
{
    return m_impl->getTopStoriesAndKeywords(thresholdPercentage, topStories,
                                                                  topKeywords);
}
