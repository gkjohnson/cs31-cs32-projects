#include "Actor.h"
#include "World.h"
#include <cstdlib>
// Your code goes here

//Actor Functions
Actor::Actor(World* w, int x, int y, int id, colors c)
	:m_world(w), m_x(x), m_y(y), m_id(id), m_color(c), m_dir(NONE)
{}

//NachMan Functions
NachMan::NachMan(World* w, int x, int y)
	:Actor(w,x,y,ITEM_NACHMAN,YELLOW), m_lives(3), m_score(0)
{}
void NachMan::DoSomething()
{

	//PLAYER INPUT
	char ch;

	if(getCharIfAny(ch)){
		GridContents gc;
		Direction d;

		switch(ch){
		case ARROW_LEFT:
			gc=GetWorld()->GetMaze()->GetGridContents(GetX()-1,GetY());
			d=WEST;
			break;
		case ARROW_RIGHT:
			gc=GetWorld()->GetMaze()->GetGridContents(GetX()+1,GetY());
			d=EAST;
			break;
		case ARROW_UP:
			gc=GetWorld()->GetMaze()->GetGridContents(GetX(),GetY()-1);
			d=NORTH;
			break;
		case ARROW_DOWN:
			gc=GetWorld()->GetMaze()->GetGridContents(GetX(),GetY()+1);
			d=SOUTH;
			break;
		}
		switch(ch){
		case ARROW_LEFT:
		case ARROW_RIGHT:
		case ARROW_UP:
		case ARROW_DOWN:
			if(gc!=WALL&&gc!=CAGEDOOR){
				setDir(d);
			}
		}
	}

	//MOVEMENT
	{
		int nextX=GetX();
		int nextY=GetY();

		switch(getDir()){
		case WEST:
			nextX--;
			break;
		case EAST:
			nextX++;
			break;
		case NORTH:
			nextY--;
			break;
		case SOUTH:
			nextY++;
			break;
		}

		GridContents gc=GetWorld()->GetMaze()->GetGridContents(nextX,nextY);

		if(gc!=WALL&&gc!=CAGEDOOR){
			SetX(nextX);
			SetY(nextY);
		}
	}

	//PELLET EATING
	{
		GridContents gc=GetWorld()->GetMaze()->GetGridContents(GetX(),GetY());
		
		if(gc==PELLET){	//Small Pellet
			addToScore(10);
			GetWorld()->GetMaze()->SetGridContents(GetX(),GetY(),EMPTY);
			SoundFX::playNachManSound(PAC_SOUND_SMALL_EAT);
		}else if(gc==POWERPELLET){ //Power Pellet
			addToScore(100);
			GetWorld()->GetMaze()->SetGridContents(GetX(),GetY(),EMPTY);
			SoundFX::playNachManSound(PAC_SOUND_BIG_EAT);

			//update all the monster's states to be vulnerable if applicable
			for(int i=0; i<NUM_MONSTERS;i++){
				if(GetWorld()->GetMonster(i)->GetState()==NORMAL||GetWorld()->GetMonster(i)->GetState()==VULNERABLE){
					GetWorld()->GetMonster(i)->SetState(VULNERABLE);
				}
			}
		}
	}
	
	//MONSTER HIT CHECKS
	for(int i=0;i<NUM_MONSTERS;i++){
		hitMonsterCheck(GetWorld()->GetMonster(i));
	}
}
void NachMan::hitMonsterCheck(Monster* m){
	if(m->GetX()==GetX()&&m->GetY()==GetY()){
		if(m->GetState()==VULNERABLE){
			m->eaten();
			addToScore(1000);
		}else if(m->GetState()==NORMAL){
			setDead();
		}
	}
}

//Monster Functions
Monster::Monster(World* w, int x, int y, int id, colors c)
	:Actor(w, x, y, id, c), m_state(NORMAL), m_vulnerableTicks(0), destX(0),destY(0)
{}
colors Monster::GetDisplayColor() const
{
	if(m_state==RETURN_HOME){
		return LIGHTGRAY;
	}else if(m_state==VULNERABLE||m_state==MONSTER_DIE){
		return LIGHTBLUE;
	}
	return Actor::GetDisplayColor();
}
void Monster::decrementVulnerability(){

	if(m_vulnerableTicks>0){
		m_vulnerableTicks--;
	}
	if(m_vulnerableTicks==0){
		m_state=NORMAL;
	}
}
void Monster::DoSomething()
{
	if(m_state==NORMAL||m_state==VULNERABLE)
	{
		decrementVulnerability();

		decideDest();
		move();
		
		hitNachmanCheck();
	}
	else if(m_state==RETURN_HOME)
	{
		if(GetX()==GetWorld()->GetMaze()->GetMonsterStartX()&&
			GetY()==GetWorld()->GetMaze()->GetMonsterStartY()){
				SetState(NORMAL);
		}
	}
	else if(m_state==MONSTER_DIE)
	{
		m_vulnerableTicks=0;
		m_state=RETURN_HOME;
		SoundFX::playNachManSound(PAC_SOUND_BIG_EAT);
	}
}
void Monster::move(){
	//1 and 2 for the movement algorithm
	if(GetX()!=destX){
		if(GetX()>destX) //destination is to the WEST
		{
			if(GetWorld()->GetMaze()->GetGridContents(GetX()-1,GetY())!=WALL&&
				getDir()!=EAST)
			{
				SetX(GetX()-1);
				setDir(WEST);
				return;
			}
		}else if(GetX()<destX) //destination is to the EAST
		{
			if(GetWorld()->GetMaze()->GetGridContents(GetX()+1,GetY())!=WALL&&
				getDir()!=WEST)
			{
				SetX(GetX()+1);
				setDir(EAST);
				return;
			}
		}
	}
	//3 and 4 for the movement algorithm
	if(GetY()!=destY){
		if(GetY()>destY) //destination is NORTH
		{
			if(GetWorld()->GetMaze()->GetGridContents(GetX(),GetY()-1)!=WALL&&
				getDir()!=SOUTH)
			{
				SetY(GetY()-1);
				setDir(NORTH);
				return;
			}
		}else if(GetY()<destY) //destination is to the SOUTH
		{
			if(GetWorld()->GetMaze()->GetGridContents(GetX(),GetY()+1)!=WALL&&
				getDir()!=NORTH)
			{
				SetY(GetY()+1);
				setDir(SOUTH);
				return;
			}
		}
	}

	//5 and 6 for the movement algorithm
	Direction D=(Direction)(rand()%4);
	for(int i=0; i<4;i++){
		int newX=GetX();
		int newY=GetY();
		bool opposite=false;

		switch(D){
		case NORTH:
			newY--;
			if(getDir()==SOUTH){
				opposite=true;
			}
			break;
		case SOUTH:
			newY++;
			if(getDir()==NORTH){
				opposite=true;
			}
			break;
		case WEST:
			newX--;
			if(getDir()==EAST){
				opposite=true;
			}
			break;
		case EAST:
			newX++;
			if(getDir()==WEST){
				opposite=true;
			}
			break;
		}
		if(GetWorld()->GetMaze()->GetGridContents(newX,newY)==WALL || opposite){
			D=(Direction)(((int)D+1)%4);
			continue;
		}

		SetX(newX);
		SetY(newY);
		setDir(D);
		return;
	}

	//7 from the movement algorithm
	int newX=GetX();
	int newY=GetY();
	switch(getDir()){
	case NORTH:
		SetY(GetY()+1);
		setDir(SOUTH);
		break;
	case SOUTH:
		SetY(GetY()-1);
		setDir(NORTH);
		break;
	case EAST:
		SetX(GetX()-1);
		setDir(WEST);
		break;
	case WEST:
		SetX(GetX()+1);
		setDir(EAST);
		break;
	}
	return;

}
void Monster::eaten()
{
	this->SetState(MONSTER_DIE);
}
void Monster::hitNachmanCheck(){
	GetWorld()->GetNachMan()->hitMonsterCheck(this);
}
void Monster::decideDest(){
	if(m_state==NORMAL){
		whileNormal();
	}
	else if(m_state==VULNERABLE){
		whileVulnerable();
	}
	
}
void Monster::SetState(MonsterState m)
{
	m_state=m;
	if(m==VULNERABLE){
		if(GetWorld()->GetLevel()>8){
			m_vulnerableTicks=20;
		}else{
			m_vulnerableTicks=100-(GetWorld()->GetLevel())*10;
		}
	}
}

//Inky Functions
Inky::Inky(World* w, int x, int y)
	:Monster(w,x,y,ITEM_MONSTER1,LIGHTRED), m_decideTicks(0)
{}
void Inky::whileNormal(){
	//steps 1 and 2 of the algorithm
	if(m_decideTicks>0){
		m_decideTicks--;
	}
	if(m_decideTicks==0){
		m_decideNum=rand()%100;
		m_decideTicks=10;
	} 

	if(m_decideNum<80){
		SetDest(GetWorld()->GetNachMan()->GetX(),GetWorld()->GetNachMan()->GetY());
	}else{
		whileVulnerable();
	}
}
void Inky::whileVulnerable()
{
	SetDest(rand()%MAZE_WIDTH,rand()%MAZE_HEIGHT);
}

//Stinky Functions
Stinky::Stinky(World* w, int x, int y)
	:Monster(w,x,y,ITEM_MONSTER2,LIGHTGREEN)
{}
void Stinky::whileNormal()
{


}
void Stinky::whileVulnerable()
{}

//Dinky Functions
Dinky::Dinky(World* w, int x, int y)
	:Monster(w,x,y,ITEM_MONSTER3,LIGHTMAGENTA)
{}
void Dinky::whileNormal()
{}
void Dinky::whileVulnerable()
{}

//Clyde Functions
Clyde::Clyde(World* w, int x, int y)
	:Monster(w,x,y,ITEM_MONSTER4,LIGHTCYAN)
{}
void Clyde::whileNormal()
{
	SetDest(rand()%MAZE_WIDTH,rand()%MAZE_HEIGHT);
}
void Clyde::whileVulnerable()
{
	//NachMan's Quadrant
	int quadX=(GetWorld()->GetNachMan()->GetX())/(MAZE_WIDTH/2);
	int quadY=(GetWorld()->GetNachMan()->GetY())/(MAZE_HEIGHT/2);

	//Clyde's Quadrant
	int cQuadX=(quadX+1)%2;
	int cQuadY=(quadY+1)%2;

	SetDest(cQuadX*(MAZE_WIDTH/2)+rand()%(MAZE_WIDTH/2),cQuadY*(MAZE_HEIGHT/2)+rand()%(MAZE_HEIGHT/2));
}