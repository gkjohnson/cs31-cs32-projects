#ifndef _MYMAZE_H_
#define _MYMAZE_H_

#include "Maze.h"

class MyMaze: public Maze
{
  public:

	MyMaze(GraphManager* gm)
		: Maze(gm)
	{
	}

	virtual bool GetNextCoordinate(int nCurX, int nCurY, int &nNextX, int &nNextY);
  // You may add additional code
};

#endif //  _MYMAZE_H_
