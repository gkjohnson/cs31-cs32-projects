#include "MyMaze.h"
#include "constants.h"
#include <stack>

// Add student code here, if required

bool MyMaze::GetNextCoordinate(int nCurX, int nCurY, int &nNextX, int &nNextY){

	int dist[21][15];



	return false;
}