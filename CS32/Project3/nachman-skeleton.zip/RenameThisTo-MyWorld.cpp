#include "MyWorld.h"

GameStatus MyWorld::RunLevel()
{
	  // Replace this with your implementation of RunLevel

	return PLAYER_DIED;
}
